import QtQuick 2.12
Item {
    id: host
    anchors.fill: parent
    signal positionSaveRequested(real x, real y)
    property bool mainScreen: true
    property bool dragging: false
    property bool suppressClick: false
    property real startPointerX: 0
    property real startPointerY: 0
    property real startButtonX: 0
    property real startButtonY: 0
    onMainScreenChanged: if (!mainScreen) analyzer.close()
    function clampX(value) { return Math.max(0, Math.min(value, width - button.width)) }
    function clampY(value) { return Math.max(0, Math.min(value, height - button.height)) }
    function restorePosition(savedX, savedY) {
        if (savedX >= 0 && savedY >= 0) {
            button.x = clampX(savedX)
            button.y = clampY(savedY)
        }
    }
    function openAnalyzer() { if (mainScreen) analyzer.open() }
    function closeAnalyzer() { analyzer.close() }
    Analyzer { id: analyzer }
    Rectangle {
        id: button
        visible: host.mainScreen && !analyzer.visible
        z: 20
        x: 8
        y: 8
        width: 148
        height: 36
        radius: 6
        color: host.dragging ? "#35485a" : "#28323c"
        border.color: "#35414d"
        Text { anchors.centerIn: parent; text: "Audio Analyzer"; color: "white"; font.pixelSize: 14 }
        MouseArea {
            anchors.fill: parent
            onPressed: {
                var point = mapToItem(host, mouse.x, mouse.y)
                host.startPointerX = point.x
                host.startPointerY = point.y
                host.startButtonX = button.x
                host.startButtonY = button.y
            }
            onPressAndHold: host.dragging = true
            onPositionChanged: {
                if (!host.dragging) return
                var point = mapToItem(host, mouse.x, mouse.y)
                button.x = host.clampX(host.startButtonX + point.x - host.startPointerX)
                button.y = host.clampY(host.startButtonY + point.y - host.startPointerY)
            }
            onReleased: {
                if (host.dragging) {
                    host.dragging = false
                    host.suppressClick = true
                    host.positionSaveRequested(button.x, button.y)
                }
            }
            onClicked: {
                if (host.suppressClick) {
                    host.suppressClick = false
                    return
                }
                host.openAnalyzer()
            }
            onCanceled: {
                host.dragging = false
                host.suppressClick = false
            }
        }
    }
}
