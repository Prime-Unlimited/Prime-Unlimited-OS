import QtQuick 2.12
Item {
    id: root
    anchors.fill: parent
    visible: false
    z: 10000
    readonly property int barCount: 31
    readonly property real barPitch: 8.6
    readonly property real barTop: 36
    property bool live: false
    property int mode: 0
    property int selectedPair: 2
    property int rate: 0
    property real binHz: 0
    property real drops: 0
    property var wave: []
    property var spectrum: []
    property var levels: []
    property var holds: [-160, -160, -160, -160, -160, -160, -160, -160]
    property bool pending: false
    property int inflightTicks: 0
    property int generation: 0
    property var xhr: null
    function open() {
        generation++
        levels = []
        wave = []
        spectrum = []
        live = false
        pending = false
        inflightTicks = 0
        reset()
        visible = true
    }
    function close() {
        generation++
        visible = false
        live = false
        levels = []
        wave = []
        spectrum = []
        pending = false
        if (xhr) xhr.abort()
        xhr = null
    }
    function reset() { holds = [-160, -160, -160, -160, -160, -160, -160, -160] }
    function fetch() {
        if (!visible) return
        if (pending) {
            inflightTicks++
            if (inflightTicks > 8 && xhr) {
                xhr.abort()
                pending = false
                inflightTicks = 0
                live = false
                levels = []
                wave = []
                spectrum = []
            }
            return
        }
        inflightTicks = 0
        pending = true
        var token = generation
        var req = new XMLHttpRequest()
        xhr = req
        req.timeout = 800
        var view = mode === 3 ? 3 : (mode === 0 ? 0 : 1)
        req.onreadystatechange = function() {
            if (req.readyState !== 4) return
            if (xhr === req) pending = false
            if (token !== generation || !visible) return
            try {
                if (req.status !== 200) throw Error("HTTP")
                var d = JSON.parse(req.responseText)
                if (!d.live || !d.channels || d.channels.length !== 8) throw Error("offline")
                var h = holds.slice()
                for (var i = 0; i < 8; i++) h[i] = Math.max(h[i], d.channels[i].peak)
                holds = h
                levels = d.channels
                wave = d.wave || []
                spectrum = d.spectrum || []
                rate = d.rate || 0
                binHz = d.binHz || 0
                drops = d.drops || 0
                live = true
            } catch (e) {
                live = false
                levels = []
                wave = []
                spectrum = []
            }
        }
        req.open("GET", "http://127.0.0.1:9146/levels?view=" + view + "&pair=" + selectedPair)
        req.send()
    }
    Timer { interval: 100; repeat: true; running: root.visible; triggeredOnStart: true; onTriggered: root.fetch() }
    Rectangle { anchors.fill: parent; color: "#0c1015"; visible: root.visible }
    Item {
        width: 1280
        height: 800
        anchors.centerIn: parent
        scale: Math.min(root.width / 1280, root.height / 800)
        Text { x: 28; y: 18; text: "PRIME UNLIMITED / DIAGNOSTICS"; font.pixelSize: 15; font.letterSpacing: 2; color: "#8996a2" }
        Text { x: 28; y: 40; text: "Audio Analyzer"; font.pixelSize: 36; font.bold: true; color: "#f4f7fa" }
        Text { x: 760; y: 36; text: root.live ? "● CAPTURE LIVE" : "○ NO CAPTURE"; font.pixelSize: 20; color: root.live ? "#43e0d0" : "#e5b66d" }
        Text { x: 760; y: 64; text: "DROPS " + root.drops; font.pixelSize: 16; color: root.drops ? "#ef5c55" : "#8996a2" }
        Rectangle {
            x: 1135; y: 24; width: 116; height: 54; radius: 6; color: "#28323c"
            Text { anchors.centerIn: parent; text: "Close ×"; font.pixelSize: 21; color: "white" }
            MouseArea { anchors.fill: parent; onClicked: root.close() }
        }
        Rectangle {
            x: 28; y: 105; width: 1224; height: 53; radius: 5; color: "#19222b"
            Text { anchors.centerIn: parent; text: "8 CHANNELS     /     S32_LE     /     RAW PCM     /     PEAK + RMS"; font.pixelSize: 20; color: "#b6c6d3" }
        }
        Repeater {
            model: root.mode === 0 ? 4 : 0
            delegate: Rectangle {
                id: pair
                property int pairIndex: index
                x: 28 + index * 310
                y: 180
                width: 294
                height: 500
                radius: 7
                color: "#171e26"
                border.color: "#35414d"
                Text { anchors.horizontalCenter: parent.horizontalCenter; y: 12; text: "STEREO PAIR " + (pair.pairIndex + 1); font.pixelSize: 17; font.letterSpacing: 2; color: "#9baab8" }
                Repeater {
                    model: [0, -24, -48, -72, -96, -120]
                    delegate: Text {
                        x: 8
                        y: 48 + root.barTop + (-modelData / 4) * root.barPitch - 8
                        text: modelData
                        color: "#8996a2"
                        font.pixelSize: 13
                    }
                }
                Repeater {
                    model: 2
                    delegate: Item {
                        id: meter
                        property int ch: pair.pairIndex * 2 + index
                        property var data: root.live ? root.levels[ch] : null
                        x: 78 + index * 88
                        y: 48
                        width: 70
                        height: 440
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: "CH " + meter.ch; color: "white"; font.pixelSize: 20; font.bold: true }
                        Repeater {
                            model: root.barCount
                            delegate: Rectangle {
                                property real threshold: -index * 4
                                x: 12
                                y: root.barTop + index * root.barPitch
                                width: 46
                                height: 6.5
                                radius: 1
                                color: meter.data && meter.data.peak >= threshold ? (threshold >= -6 ? "#ef5c55" : threshold >= -18 ? "#d4bd48" : "#35c8a6") : "#26323d"
                            }
                        }
                        Rectangle {
                            x: 8
                            y: root.barTop + Math.max(0, Math.min(root.barCount - 1, -root.holds[meter.ch] / 4)) * root.barPitch
                            width: 54
                            height: 2
                            color: "#edf4fa"
                            visible: root.live && root.holds[meter.ch] >= -120
                        }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 330; text: meter.data ? meter.data.peak.toFixed(1) : "—"; font.pixelSize: 20; color: "#43e0d0" }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 354; text: "PEAK dBFS"; font.pixelSize: 11; color: "#8996a2" }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 372; text: meter.data ? meter.data.rms.toFixed(1) : "—"; font.pixelSize: 18; color: "#edf4fa" }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; y: 394; text: "RMS dBFS"; font.pixelSize: 11; color: "#8996a2" }
                        Text {
                            anchors.horizontalCenter: parent.horizontalCenter
                            y: 414
                            text: meter.data ? ("NEAR FS " + meter.data.nearFs) : "NEAR FS —"
                            font.pixelSize: 12
                            color: meter.data && meter.data.nearFs ? "#ef5c55" : "#8996a2"
                        }
                    }
                }
            }
        }
        ScopeView {
            x: 28
            y: 180
            width: 1224
            height: 500
            visible: root.mode !== 0
            wave: root.live ? root.wave : []
            spectrum: root.live ? root.spectrum : []
            pair: root.selectedPair
            mode: root.mode
            rate: root.rate
            binHz: root.binHz
        }
        Repeater {
            model: ["LEVELS", "OSCILLOSCOPE", "STEREO SCOPE", "SPECTRUM"]
            delegate: Rectangle {
                x: 28 + index * 165
                y: 704
                width: 155
                height: 58
                radius: 5
                color: root.mode === index ? "#17675f" : "#28323c"
                Text { anchors.centerIn: parent; text: modelData; color: "white"; font.pixelSize: 15 }
                MouseArea { anchors.fill: parent; onClicked: root.mode = index }
            }
        }
        Rectangle {
            x: 700; y: 704; width: 250; height: 58; radius: 5; color: "#28323c"; visible: root.mode !== 0
            Text { anchors.centerIn: parent; text: "PAIR " + (root.selectedPair + 1) + "  /  CH " + (root.selectedPair * 2) + "/" + (root.selectedPair * 2 + 1); color: "white"; font.pixelSize: 18 }
            MouseArea { anchors.fill: parent; onClicked: root.selectedPair = (root.selectedPair + 1) % 4 }
        }
        Rectangle {
            x: 990; y: 704; width: 262; height: 58; radius: 5; color: "#17675f"; visible: root.mode === 0
            Text { anchors.centerIn: parent; text: "Reset peak hold"; color: "white"; font.pixelSize: 20 }
            MouseArea { anchors.fill: parent; onClicked: root.reset() }
        }
        Text {
            x: 28
            y: 770
            width: 1224
            text: "READ ONLY  /  NO AUDIO MODIFICATION  /  NEAR FS >= 99.9% FULL SCALE, NOT ANALOG CLIPPING  /  CH 4/5 = DECK 4 LINE"
            font.pixelSize: 13
            color: "#8996a2"
        }
    }
}
