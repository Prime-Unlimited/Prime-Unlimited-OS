import QtQuick 2.12
Rectangle {
    id: scope
    color: "#171e26"
    radius: 7
    border.color: "#35414d"
    property var wave: []
    property var spectrum: []
    property int pair: 0
    property int mode: 1
    property int rate: 0
    property real binHz: 0
    onSpectrumChanged: plot.requestPaint()
    onWaveChanged: plot.requestPaint()
    onPairChanged: plot.requestPaint()
    onModeChanged: plot.requestPaint()
    onVisibleChanged: plot.requestPaint()
    onBinHzChanged: plot.requestPaint()
    Text {
        x: 20
        y: 12
        color: "#edf4fa"
        font.pixelSize: 22
        text: scope.mode === 1 ? "RAW WAVEFORM / ± FULL SCALE"
              : scope.mode === 2 ? "STEREO XY / ± FULL SCALE"
              : scope.rate ? ("SPECTRUM / dBFS / " + scope.rate + " Hz / " + scope.binHz.toFixed(2) + " Hz/bin")
              : "SPECTRUM / RATE UNKNOWN"
    }
    Text {
        x: 20
        y: 45
        color: "#8996a2"
        font.pixelSize: 15
        text: "CH " + (scope.pair * 2) + " (teal) / CH " + (scope.pair * 2 + 1) + " (white) — no gain"
    }
    Canvas {
        id: plot
        x: 70
        y: 80
        width: scope.width - 140
        height: scope.height - 115
        onPaint: {
            var c = getContext("2d")
            c.clearRect(0, 0, width, height)
            var w = width, h = height
            c.strokeStyle = "#35414d"
            c.lineWidth = 1
            for (var i = 0; i <= 8; i++) {
                c.beginPath(); c.moveTo(i * w / 8, 0); c.lineTo(i * w / 8, h); c.stroke()
                c.beginPath(); c.moveTo(0, i * h / 8); c.lineTo(w, i * h / 8); c.stroke()
            }
            if (scope.mode === 3) {
                if (scope.spectrum.length !== 2) return
                for (var ch = 0; ch < 2; ch++) {
                    var bins = scope.spectrum[ch]
                    if (!bins || !bins.length) return
                    c.strokeStyle = ch ? "#edf4fa" : "#43e0d0"
                    c.beginPath()
                    var denom = Math.max(1, bins.length - 1)
                    for (var b = 0; b < bins.length; b++) {
                        var x = b * w / denom
                        var y = h * Math.max(0, Math.min(1, -bins[b] / 120))
                        if (b) c.lineTo(x, y)
                        else c.moveTo(x, y)
                    }
                    c.stroke()
                }
                return
            }
            if (scope.wave.length !== 2) return
            var a = scope.wave[0], bch = scope.wave[1]
            if (!a || !bch || !a.length || a.length !== bch.length) return
            c.lineWidth = 1.5
            if (scope.mode === 1) {
                for (var side = 0; side < 2; side++) {
                    var v = side ? bch : a
                    c.strokeStyle = side ? "#edf4fa" : "#43e0d0"
                    c.beginPath()
                    for (var j = 0; j < v.length; j++) {
                        var xx = j * w / Math.max(1, v.length - 1)
                        var yy = h * (1 - v[j]) / 2
                        if (j) c.lineTo(xx, yy)
                        else c.moveTo(xx, yy)
                    }
                    c.stroke()
                }
            } else {
                var sidepx = Math.min(w, h)
                c.strokeStyle = "#43e0d0"
                c.beginPath()
                for (var k = 0; k < a.length; k++) {
                    var xy = w / 2 + a[k] * sidepx / 2
                    var yx = h / 2 - bch[k] * sidepx / 2
                    if (k) c.lineTo(xy, yx)
                    else c.moveTo(xy, yx)
                }
                c.stroke()
            }
        }
    }
    Text { x: 8; y: 80; text: scope.mode === 3 ? "0 dB" : "+1"; color: "#8996a2" }
    Text { x: 8; y: scope.height / 2; text: scope.mode === 3 ? "−60" : "0"; color: "#8996a2" }
    Text { x: 8; y: scope.height - 50; text: scope.mode === 3 ? "−120" : "−1"; color: "#8996a2" }
}
